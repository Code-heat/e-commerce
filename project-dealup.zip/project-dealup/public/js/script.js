document.querySelector('.icon .fa-bars').addEventListener("click",() => {
   document.querySelector('ul.categories').classList.toggle('close')
})